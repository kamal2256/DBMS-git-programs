-- AIM 2.1: DELETE Command
DELETE FROM students WHERE rollno='24B11CS381';