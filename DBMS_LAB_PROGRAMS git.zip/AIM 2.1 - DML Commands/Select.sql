-- AIM 2.1: SELECT Command
SELECT * FROM students;
SELECT name FROM students;
SELECT * FROM students WHERE rollno='24B11CS234';