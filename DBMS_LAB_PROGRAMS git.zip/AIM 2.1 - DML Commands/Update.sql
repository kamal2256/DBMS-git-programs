-- AIM 2.1: UPDATE Command
UPDATE students SET name='Bala Raju' WHERE rollno='24B11CS381';