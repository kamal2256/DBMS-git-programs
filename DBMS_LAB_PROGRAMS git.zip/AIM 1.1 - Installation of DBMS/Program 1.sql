-- AIM 1.1: Familiarization with installation of any DBMS
-- Description: Installation of Oracle 10g Express Edition

-- No executable SQL code for this AIM (installation steps only)
-- Follow manual installation steps provided in the lab manual.